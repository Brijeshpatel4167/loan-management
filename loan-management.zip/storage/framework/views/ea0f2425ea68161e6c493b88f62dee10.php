

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>EMI Details</h1>
    <form action="<?php echo e(route('emi.details.process')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-primary">Process Data</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\loan-management\resources\views/emi_details/index.blade.php ENDPATH**/ ?>